--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4 (Ubuntu 16.4-1.pgdg24.04+2)
-- Dumped by pg_dump version 16.4 (Ubuntu 16.4-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE projeto_gpatri;
--
-- Name: projeto_gpatri; Type: DATABASE; Schema: -; Owner: guilherme
--

CREATE DATABASE projeto_gpatri WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE projeto_gpatri OWNER TO guilherme;

\connect projeto_gpatri

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: atividades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.atividades (
    atividade_id integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao character varying(500)
);


ALTER TABLE public.atividades OWNER TO postgres;

--
-- Name: atividades_atividade_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.atividades_atividade_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.atividades_atividade_id_seq OWNER TO postgres;

--
-- Name: atividades_atividade_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.atividades_atividade_id_seq OWNED BY public.atividades.atividade_id;


--
-- Name: ativproj; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ativproj (
    atividade_id integer NOT NULL,
    projeto_id integer NOT NULL
);


ALTER TABLE public.ativproj OWNER TO postgres;

--
-- Name: cargos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cargos (
    cargo_id integer NOT NULL,
    cargo character varying(40) NOT NULL,
    nivel_acesso character varying(40) NOT NULL
);


ALTER TABLE public.cargos OWNER TO postgres;

--
-- Name: cargos_cargo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cargos_cargo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cargos_cargo_id_seq OWNER TO postgres;

--
-- Name: cargos_cargo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cargos_cargo_id_seq OWNED BY public.cargos.cargo_id;


--
-- Name: categorias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categorias (
    categoria_id integer NOT NULL,
    categoria character varying(100) NOT NULL
);


ALTER TABLE public.categorias OWNER TO postgres;

--
-- Name: categorias_categoria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categorias_categoria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categorias_categoria_id_seq OWNER TO postgres;

--
-- Name: categorias_categoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categorias_categoria_id_seq OWNED BY public.categorias.categoria_id;


--
-- Name: checkins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.checkins (
    checkin_id integer NOT NULL,
    dataa date NOT NULL,
    horario time without time zone NOT NULL,
    usuario_id integer NOT NULL
);


ALTER TABLE public.checkins OWNER TO postgres;

--
-- Name: checkins_checkin_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.checkins_checkin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.checkins_checkin_id_seq OWNER TO postgres;

--
-- Name: checkins_checkin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.checkins_checkin_id_seq OWNED BY public.checkins.checkin_id;


--
-- Name: condicoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.condicoes (
    condicao_id integer NOT NULL,
    condicao character varying(100) NOT NULL
);


ALTER TABLE public.condicoes OWNER TO postgres;

--
-- Name: condicoes_condicao_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.condicoes_condicao_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.condicoes_condicao_id_seq OWNER TO postgres;

--
-- Name: condicoes_condicao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.condicoes_condicao_id_seq OWNED BY public.condicoes.condicao_id;


--
-- Name: emprestimos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.emprestimos (
    emprestimo_id integer NOT NULL,
    usuario_responsavel_id integer NOT NULL,
    item_patrimonio_id integer NOT NULL,
    usuario_id integer NOT NULL,
    data_emprestimo date NOT NULL,
    data_devolucao date NOT NULL
);


ALTER TABLE public.emprestimos OWNER TO postgres;

--
-- Name: emprestimos_emprestimo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.emprestimos_emprestimo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.emprestimos_emprestimo_id_seq OWNER TO postgres;

--
-- Name: emprestimos_emprestimo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.emprestimos_emprestimo_id_seq OWNED BY public.emprestimos.emprestimo_id;


--
-- Name: instituicoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.instituicoes (
    instituicao_id integer NOT NULL,
    nome character varying(100) NOT NULL,
    cnpj character varying(14),
    pes_responsavel character varying(100)
);


ALTER TABLE public.instituicoes OWNER TO postgres;

--
-- Name: instituicoes_instituicao_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.instituicoes_instituicao_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.instituicoes_instituicao_id_seq OWNER TO postgres;

--
-- Name: instituicoes_instituicao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.instituicoes_instituicao_id_seq OWNED BY public.instituicoes.instituicao_id;


--
-- Name: itens_patrimonio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.itens_patrimonio (
    item_patrimonio_id integer NOT NULL,
    patrimonio_id integer NOT NULL,
    situacao_id integer NOT NULL,
    condicao_id integer NOT NULL
);


ALTER TABLE public.itens_patrimonio OWNER TO postgres;

--
-- Name: itens_patrimonio_item_patrimonio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.itens_patrimonio_item_patrimonio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.itens_patrimonio_item_patrimonio_id_seq OWNER TO postgres;

--
-- Name: itens_patrimonio_item_patrimonio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.itens_patrimonio_item_patrimonio_id_seq OWNED BY public.itens_patrimonio.item_patrimonio_id;


--
-- Name: parceiros; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parceiros (
    instituicao_id integer NOT NULL,
    projeto_id integer NOT NULL
);


ALTER TABLE public.parceiros OWNER TO postgres;

--
-- Name: patrimonios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patrimonios (
    patrimonio_id integer NOT NULL,
    nome character varying(100) NOT NULL,
    valor_estimado double precision NOT NULL,
    descricao character varying(500),
    categoria_id integer NOT NULL
);


ALTER TABLE public.patrimonios OWNER TO postgres;

--
-- Name: patrimonios_patrimonio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.patrimonios_patrimonio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patrimonios_patrimonio_id_seq OWNER TO postgres;

--
-- Name: patrimonios_patrimonio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.patrimonios_patrimonio_id_seq OWNED BY public.patrimonios.patrimonio_id;


--
-- Name: possuiskill; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.possuiskill (
    skill_id integer NOT NULL,
    usuario_id integer NOT NULL
);


ALTER TABLE public.possuiskill OWNER TO postgres;

--
-- Name: projetos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projetos (
    projeto_id integer NOT NULL,
    nome character varying(200) NOT NULL,
    area_pesquisa character varying(100),
    tipo_projeto character varying(50) NOT NULL,
    descricao character varying(500)
);


ALTER TABLE public.projetos OWNER TO postgres;

--
-- Name: projetos_projeto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.projetos_projeto_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projetos_projeto_id_seq OWNER TO postgres;

--
-- Name: projetos_projeto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.projetos_projeto_id_seq OWNED BY public.projetos.projeto_id;


--
-- Name: situacoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.situacoes (
    situacao_id integer NOT NULL,
    situacao character varying(100) NOT NULL
);


ALTER TABLE public.situacoes OWNER TO postgres;

--
-- Name: situacoes_situacao_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.situacoes_situacao_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.situacoes_situacao_id_seq OWNER TO postgres;

--
-- Name: situacoes_situacao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.situacoes_situacao_id_seq OWNED BY public.situacoes.situacao_id;


--
-- Name: skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.skills (
    skill_id integer NOT NULL,
    skill character varying(50) NOT NULL
);


ALTER TABLE public.skills OWNER TO postgres;

--
-- Name: skills_skill_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.skills_skill_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.skills_skill_id_seq OWNER TO postgres;

--
-- Name: skills_skill_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.skills_skill_id_seq OWNED BY public.skills.skill_id;


--
-- Name: subcategorias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subcategorias (
    subcategoria_id integer NOT NULL,
    subcategoria character varying(100) NOT NULL,
    categoria_id integer NOT NULL
);


ALTER TABLE public.subcategorias OWNER TO postgres;

--
-- Name: subcategorias_subcategoria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subcategorias_subcategoria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subcategorias_subcategoria_id_seq OWNER TO postgres;

--
-- Name: subcategorias_subcategoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subcategorias_subcategoria_id_seq OWNED BY public.subcategorias.subcategoria_id;


--
-- Name: userativ; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.userativ (
    atividade_id integer NOT NULL,
    usuario_id integer NOT NULL,
    funcao character varying(100) NOT NULL
);


ALTER TABLE public.userativ OWNER TO postgres;

--
-- Name: userproj; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.userproj (
    usuario_id integer NOT NULL,
    projeto_id integer NOT NULL,
    funcao character varying(100) NOT NULL
);


ALTER TABLE public.userproj OWNER TO postgres;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    usuario_id integer NOT NULL,
    nome character varying(40) NOT NULL,
    sobrenome character varying(40) NOT NULL,
    matricula character varying(15) NOT NULL,
    senha character varying(100) NOT NULL,
    email character varying(255),
    cpf character varying(11),
    cargo_id integer NOT NULL
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_usuario_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_usuario_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuarios_usuario_id_seq OWNER TO postgres;

--
-- Name: usuarios_usuario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_usuario_id_seq OWNED BY public.usuarios.usuario_id;


--
-- Name: atividades atividade_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atividades ALTER COLUMN atividade_id SET DEFAULT nextval('public.atividades_atividade_id_seq'::regclass);


--
-- Name: cargos cargo_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cargos ALTER COLUMN cargo_id SET DEFAULT nextval('public.cargos_cargo_id_seq'::regclass);


--
-- Name: categorias categoria_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias ALTER COLUMN categoria_id SET DEFAULT nextval('public.categorias_categoria_id_seq'::regclass);


--
-- Name: checkins checkin_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkins ALTER COLUMN checkin_id SET DEFAULT nextval('public.checkins_checkin_id_seq'::regclass);


--
-- Name: condicoes condicao_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.condicoes ALTER COLUMN condicao_id SET DEFAULT nextval('public.condicoes_condicao_id_seq'::regclass);


--
-- Name: emprestimos emprestimo_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emprestimos ALTER COLUMN emprestimo_id SET DEFAULT nextval('public.emprestimos_emprestimo_id_seq'::regclass);


--
-- Name: instituicoes instituicao_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instituicoes ALTER COLUMN instituicao_id SET DEFAULT nextval('public.instituicoes_instituicao_id_seq'::regclass);


--
-- Name: itens_patrimonio item_patrimonio_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens_patrimonio ALTER COLUMN item_patrimonio_id SET DEFAULT nextval('public.itens_patrimonio_item_patrimonio_id_seq'::regclass);


--
-- Name: patrimonios patrimonio_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patrimonios ALTER COLUMN patrimonio_id SET DEFAULT nextval('public.patrimonios_patrimonio_id_seq'::regclass);


--
-- Name: projetos projeto_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projetos ALTER COLUMN projeto_id SET DEFAULT nextval('public.projetos_projeto_id_seq'::regclass);


--
-- Name: situacoes situacao_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.situacoes ALTER COLUMN situacao_id SET DEFAULT nextval('public.situacoes_situacao_id_seq'::regclass);


--
-- Name: skills skill_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skills ALTER COLUMN skill_id SET DEFAULT nextval('public.skills_skill_id_seq'::regclass);


--
-- Name: subcategorias subcategoria_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcategorias ALTER COLUMN subcategoria_id SET DEFAULT nextval('public.subcategorias_subcategoria_id_seq'::regclass);


--
-- Name: usuarios usuario_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN usuario_id SET DEFAULT nextval('public.usuarios_usuario_id_seq'::regclass);


--
-- Data for Name: atividades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.atividades (atividade_id, nome, descricao) FROM stdin;
\.
COPY public.atividades (atividade_id, nome, descricao) FROM '$$PATH$$/3606.dat';

--
-- Data for Name: ativproj; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ativproj (atividade_id, projeto_id) FROM stdin;
\.
COPY public.ativproj (atividade_id, projeto_id) FROM '$$PATH$$/3614.dat';

--
-- Data for Name: cargos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cargos (cargo_id, cargo, nivel_acesso) FROM stdin;
\.
COPY public.cargos (cargo_id, cargo, nivel_acesso) FROM '$$PATH$$/3584.dat';

--
-- Data for Name: categorias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categorias (categoria_id, categoria) FROM stdin;
\.
COPY public.categorias (categoria_id, categoria) FROM '$$PATH$$/3592.dat';

--
-- Data for Name: checkins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.checkins (checkin_id, dataa, horario, usuario_id) FROM stdin;
\.
COPY public.checkins (checkin_id, dataa, horario, usuario_id) FROM '$$PATH$$/3610.dat';

--
-- Data for Name: condicoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.condicoes (condicao_id, condicao) FROM stdin;
\.
COPY public.condicoes (condicao_id, condicao) FROM '$$PATH$$/3590.dat';

--
-- Data for Name: emprestimos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.emprestimos (emprestimo_id, usuario_responsavel_id, item_patrimonio_id, usuario_id, data_emprestimo, data_devolucao) FROM stdin;
\.
COPY public.emprestimos (emprestimo_id, usuario_responsavel_id, item_patrimonio_id, usuario_id, data_emprestimo, data_devolucao) FROM '$$PATH$$/3600.dat';

--
-- Data for Name: instituicoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.instituicoes (instituicao_id, nome, cnpj, pes_responsavel) FROM stdin;
\.
COPY public.instituicoes (instituicao_id, nome, cnpj, pes_responsavel) FROM '$$PATH$$/3608.dat';

--
-- Data for Name: itens_patrimonio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.itens_patrimonio (item_patrimonio_id, patrimonio_id, situacao_id, condicao_id) FROM stdin;
\.
COPY public.itens_patrimonio (item_patrimonio_id, patrimonio_id, situacao_id, condicao_id) FROM '$$PATH$$/3598.dat';

--
-- Data for Name: parceiros; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parceiros (instituicao_id, projeto_id) FROM stdin;
\.
COPY public.parceiros (instituicao_id, projeto_id) FROM '$$PATH$$/3615.dat';

--
-- Data for Name: patrimonios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patrimonios (patrimonio_id, nome, valor_estimado, descricao, categoria_id) FROM stdin;
\.
COPY public.patrimonios (patrimonio_id, nome, valor_estimado, descricao, categoria_id) FROM '$$PATH$$/3596.dat';

--
-- Data for Name: possuiskill; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.possuiskill (skill_id, usuario_id) FROM stdin;
\.
COPY public.possuiskill (skill_id, usuario_id) FROM '$$PATH$$/3611.dat';

--
-- Data for Name: projetos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projetos (projeto_id, nome, area_pesquisa, tipo_projeto, descricao) FROM stdin;
\.
COPY public.projetos (projeto_id, nome, area_pesquisa, tipo_projeto, descricao) FROM '$$PATH$$/3604.dat';

--
-- Data for Name: situacoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.situacoes (situacao_id, situacao) FROM stdin;
\.
COPY public.situacoes (situacao_id, situacao) FROM '$$PATH$$/3588.dat';

--
-- Data for Name: skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.skills (skill_id, skill) FROM stdin;
\.
COPY public.skills (skill_id, skill) FROM '$$PATH$$/3602.dat';

--
-- Data for Name: subcategorias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subcategorias (subcategoria_id, subcategoria, categoria_id) FROM stdin;
\.
COPY public.subcategorias (subcategoria_id, subcategoria, categoria_id) FROM '$$PATH$$/3594.dat';

--
-- Data for Name: userativ; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.userativ (atividade_id, usuario_id, funcao) FROM stdin;
\.
COPY public.userativ (atividade_id, usuario_id, funcao) FROM '$$PATH$$/3613.dat';

--
-- Data for Name: userproj; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.userproj (usuario_id, projeto_id, funcao) FROM stdin;
\.
COPY public.userproj (usuario_id, projeto_id, funcao) FROM '$$PATH$$/3612.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (usuario_id, nome, sobrenome, matricula, senha, email, cpf, cargo_id) FROM stdin;
\.
COPY public.usuarios (usuario_id, nome, sobrenome, matricula, senha, email, cpf, cargo_id) FROM '$$PATH$$/3586.dat';

--
-- Name: atividades_atividade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.atividades_atividade_id_seq', 1, false);


--
-- Name: cargos_cargo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cargos_cargo_id_seq', 1, false);


--
-- Name: categorias_categoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categorias_categoria_id_seq', 1, false);


--
-- Name: checkins_checkin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.checkins_checkin_id_seq', 1, false);


--
-- Name: condicoes_condicao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.condicoes_condicao_id_seq', 1, false);


--
-- Name: emprestimos_emprestimo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.emprestimos_emprestimo_id_seq', 1, false);


--
-- Name: instituicoes_instituicao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.instituicoes_instituicao_id_seq', 1, false);


--
-- Name: itens_patrimonio_item_patrimonio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.itens_patrimonio_item_patrimonio_id_seq', 1, false);


--
-- Name: patrimonios_patrimonio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.patrimonios_patrimonio_id_seq', 1, false);


--
-- Name: projetos_projeto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.projetos_projeto_id_seq', 1, false);


--
-- Name: situacoes_situacao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.situacoes_situacao_id_seq', 1, false);


--
-- Name: skills_skill_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.skills_skill_id_seq', 1, false);


--
-- Name: subcategorias_subcategoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subcategorias_subcategoria_id_seq', 1, false);


--
-- Name: usuarios_usuario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_usuario_id_seq', 1, false);


--
-- Name: atividades atividades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atividades
    ADD CONSTRAINT atividades_pkey PRIMARY KEY (atividade_id);


--
-- Name: ativproj ativproj_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ativproj
    ADD CONSTRAINT ativproj_pkey PRIMARY KEY (atividade_id, projeto_id);


--
-- Name: cargos cargos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cargos
    ADD CONSTRAINT cargos_pkey PRIMARY KEY (cargo_id);


--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (categoria_id);


--
-- Name: checkins checkins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkins
    ADD CONSTRAINT checkins_pkey PRIMARY KEY (checkin_id);


--
-- Name: condicoes condicoes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.condicoes
    ADD CONSTRAINT condicoes_pkey PRIMARY KEY (condicao_id);


--
-- Name: emprestimos emprestimos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emprestimos
    ADD CONSTRAINT emprestimos_pkey PRIMARY KEY (emprestimo_id, usuario_responsavel_id, item_patrimonio_id, usuario_id);


--
-- Name: instituicoes instituicoes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instituicoes
    ADD CONSTRAINT instituicoes_pkey PRIMARY KEY (instituicao_id);


--
-- Name: itens_patrimonio itens_patrimonio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens_patrimonio
    ADD CONSTRAINT itens_patrimonio_pkey PRIMARY KEY (item_patrimonio_id);


--
-- Name: parceiros parceiros_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parceiros
    ADD CONSTRAINT parceiros_pkey PRIMARY KEY (instituicao_id, projeto_id);


--
-- Name: patrimonios patrimonios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patrimonios
    ADD CONSTRAINT patrimonios_pkey PRIMARY KEY (patrimonio_id);


--
-- Name: possuiskill possuiskill_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.possuiskill
    ADD CONSTRAINT possuiskill_pkey PRIMARY KEY (skill_id, usuario_id);


--
-- Name: projetos projetos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projetos
    ADD CONSTRAINT projetos_pkey PRIMARY KEY (projeto_id);


--
-- Name: situacoes situacoes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.situacoes
    ADD CONSTRAINT situacoes_pkey PRIMARY KEY (situacao_id);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (skill_id);


--
-- Name: subcategorias subcategorias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcategorias
    ADD CONSTRAINT subcategorias_pkey PRIMARY KEY (subcategoria_id);


--
-- Name: userativ userativ_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userativ
    ADD CONSTRAINT userativ_pkey PRIMARY KEY (atividade_id, usuario_id);


--
-- Name: userproj userproj_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userproj
    ADD CONSTRAINT userproj_pkey PRIMARY KEY (usuario_id, projeto_id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (usuario_id);


--
-- Name: ativproj ativproj_atividade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ativproj
    ADD CONSTRAINT ativproj_atividade_id_fkey FOREIGN KEY (atividade_id) REFERENCES public.atividades(atividade_id);


--
-- Name: ativproj ativproj_projeto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ativproj
    ADD CONSTRAINT ativproj_projeto_id_fkey FOREIGN KEY (projeto_id) REFERENCES public.projetos(projeto_id);


--
-- Name: checkins checkins_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkins
    ADD CONSTRAINT checkins_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(usuario_id);


--
-- Name: emprestimos emprestimos_item_patrimonio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emprestimos
    ADD CONSTRAINT emprestimos_item_patrimonio_id_fkey FOREIGN KEY (item_patrimonio_id) REFERENCES public.itens_patrimonio(item_patrimonio_id);


--
-- Name: emprestimos emprestimos_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emprestimos
    ADD CONSTRAINT emprestimos_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(usuario_id);


--
-- Name: emprestimos emprestimos_usuario_responsavel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emprestimos
    ADD CONSTRAINT emprestimos_usuario_responsavel_id_fkey FOREIGN KEY (usuario_responsavel_id) REFERENCES public.usuarios(usuario_id);


--
-- Name: itens_patrimonio itens_patrimonio_condicao_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens_patrimonio
    ADD CONSTRAINT itens_patrimonio_condicao_id_fkey FOREIGN KEY (condicao_id) REFERENCES public.condicoes(condicao_id);


--
-- Name: itens_patrimonio itens_patrimonio_patrimonio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens_patrimonio
    ADD CONSTRAINT itens_patrimonio_patrimonio_id_fkey FOREIGN KEY (patrimonio_id) REFERENCES public.patrimonios(patrimonio_id);


--
-- Name: itens_patrimonio itens_patrimonio_situacao_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens_patrimonio
    ADD CONSTRAINT itens_patrimonio_situacao_id_fkey FOREIGN KEY (situacao_id) REFERENCES public.situacoes(situacao_id);


--
-- Name: parceiros parceiros_instituicao_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parceiros
    ADD CONSTRAINT parceiros_instituicao_id_fkey FOREIGN KEY (instituicao_id) REFERENCES public.atividades(atividade_id);


--
-- Name: parceiros parceiros_projeto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parceiros
    ADD CONSTRAINT parceiros_projeto_id_fkey FOREIGN KEY (projeto_id) REFERENCES public.projetos(projeto_id);


--
-- Name: patrimonios patrimonios_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patrimonios
    ADD CONSTRAINT patrimonios_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.categorias(categoria_id);


--
-- Name: possuiskill possuiskill_skill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.possuiskill
    ADD CONSTRAINT possuiskill_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES public.skills(skill_id);


--
-- Name: possuiskill possuiskill_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.possuiskill
    ADD CONSTRAINT possuiskill_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(usuario_id);


--
-- Name: subcategorias subcategorias_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcategorias
    ADD CONSTRAINT subcategorias_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.categorias(categoria_id);


--
-- Name: userativ userativ_atividade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userativ
    ADD CONSTRAINT userativ_atividade_id_fkey FOREIGN KEY (atividade_id) REFERENCES public.atividades(atividade_id);


--
-- Name: userativ userativ_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userativ
    ADD CONSTRAINT userativ_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(usuario_id);


--
-- Name: userproj userproj_projeto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userproj
    ADD CONSTRAINT userproj_projeto_id_fkey FOREIGN KEY (projeto_id) REFERENCES public.projetos(projeto_id);


--
-- Name: userproj userproj_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userproj
    ADD CONSTRAINT userproj_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(usuario_id);


--
-- Name: usuarios usuarios_cargo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_cargo_id_fkey FOREIGN KEY (cargo_id) REFERENCES public.cargos(cargo_id);


--
-- PostgreSQL database dump complete
--

