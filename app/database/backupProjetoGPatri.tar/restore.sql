--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4 (Ubuntu 16.4-0ubuntu0.24.04.2)
-- Dumped by pg_dump version 16.4 (Ubuntu 16.4-0ubuntu0.24.04.2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE projeto_gpatri;
--
-- Name: projeto_gpatri; Type: DATABASE; Schema: -; Owner: guilherme
--

CREATE DATABASE projeto_gpatri WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE projeto_gpatri OWNER TO guilherme;

\connect projeto_gpatri

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ativ_proj; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ativ_proj (
    id_atividade integer NOT NULL,
    id_projeto integer NOT NULL
);


ALTER TABLE public.ativ_proj OWNER TO postgres;

--
-- Name: atividades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.atividades (
    id_atividade integer NOT NULL,
    nome character varying(20) NOT NULL,
    "descrição" character varying(255)
);


ALTER TABLE public.atividades OWNER TO postgres;

--
-- Name: atividades_id_atividade_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.atividades_id_atividade_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.atividades_id_atividade_seq OWNER TO postgres;

--
-- Name: atividades_id_atividade_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.atividades_id_atividade_seq OWNED BY public.atividades.id_atividade;


--
-- Name: categorias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categorias (
    id_categoria integer NOT NULL,
    categoria character varying(255) NOT NULL
);


ALTER TABLE public.categorias OWNER TO postgres;

--
-- Name: categorias_id_categoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categorias_id_categoria_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categorias_id_categoria_seq OWNER TO postgres;

--
-- Name: categorias_id_categoria_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categorias_id_categoria_seq OWNED BY public.categorias.id_categoria;


--
-- Name: checkins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.checkins (
    id_checkin integer NOT NULL,
    id_usuario integer NOT NULL,
    dat date NOT NULL,
    hora time without time zone NOT NULL
);


ALTER TABLE public.checkins OWNER TO postgres;

--
-- Name: checkins_id_checkin_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.checkins_id_checkin_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.checkins_id_checkin_seq OWNER TO postgres;

--
-- Name: checkins_id_checkin_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.checkins_id_checkin_seq OWNED BY public.checkins.id_checkin;


--
-- Name: condicoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.condicoes (
    id_condicao integer NOT NULL,
    condicao character varying(255) NOT NULL
);


ALTER TABLE public.condicoes OWNER TO postgres;

--
-- Name: condicoes_id_condicao_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.condicoes_id_condicao_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.condicoes_id_condicao_seq OWNER TO postgres;

--
-- Name: condicoes_id_condicao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.condicoes_id_condicao_seq OWNED BY public.condicoes.id_condicao;


--
-- Name: emprestimos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.emprestimos (
    id_emprestimo integer NOT NULL,
    id_usuario_responsavel integer NOT NULL,
    id_usuario integer NOT NULL,
    id_item_patrimonio integer NOT NULL,
    dataemprestimo date NOT NULL,
    datadevolucao date NOT NULL
);


ALTER TABLE public.emprestimos OWNER TO postgres;

--
-- Name: emprestimos_id_emprestimo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.emprestimos_id_emprestimo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.emprestimos_id_emprestimo_seq OWNER TO postgres;

--
-- Name: emprestimos_id_emprestimo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.emprestimos_id_emprestimo_seq OWNED BY public.emprestimos.id_emprestimo;


--
-- Name: instituicoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.instituicoes (
    id_instituicao integer NOT NULL,
    cnpj character varying(18),
    "nomeinstituição" character varying(255) NOT NULL,
    "pesresponsável" character varying(255)
);


ALTER TABLE public.instituicoes OWNER TO postgres;

--
-- Name: instituicoes_id_instituicao_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.instituicoes_id_instituicao_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.instituicoes_id_instituicao_seq OWNER TO postgres;

--
-- Name: instituicoes_id_instituicao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.instituicoes_id_instituicao_seq OWNED BY public.instituicoes.id_instituicao;


--
-- Name: itenspatrimonio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.itenspatrimonio (
    id_item_patrimonio integer NOT NULL,
    id_patrimonio integer NOT NULL,
    id_situacao integer NOT NULL,
    id_condicao integer NOT NULL
);


ALTER TABLE public.itenspatrimonio OWNER TO postgres;

--
-- Name: itenspatrimonio_id_item_patrimonio_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.itenspatrimonio_id_item_patrimonio_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.itenspatrimonio_id_item_patrimonio_seq OWNER TO postgres;

--
-- Name: itenspatrimonio_id_item_patrimonio_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.itenspatrimonio_id_item_patrimonio_seq OWNED BY public.itenspatrimonio.id_item_patrimonio;


--
-- Name: parceiros; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parceiros (
    id_instituicao integer NOT NULL,
    id_projeto integer NOT NULL
);


ALTER TABLE public.parceiros OWNER TO postgres;

--
-- Name: patrimonios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patrimonios (
    id_patrimonio integer NOT NULL,
    id_categoria integer NOT NULL,
    nome character varying(255) NOT NULL,
    valorestimado double precision NOT NULL,
    descricao character varying(3000)
);


ALTER TABLE public.patrimonios OWNER TO postgres;

--
-- Name: patrimonios_id_patrimonio_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.patrimonios_id_patrimonio_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patrimonios_id_patrimonio_seq OWNER TO postgres;

--
-- Name: patrimonios_id_patrimonio_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.patrimonios_id_patrimonio_seq OWNED BY public.patrimonios.id_patrimonio;


--
-- Name: possuiskill; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.possuiskill (
    id_skill integer NOT NULL,
    id_usuario integer NOT NULL
);


ALTER TABLE public.possuiskill OWNER TO postgres;

--
-- Name: projetos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projetos (
    id_projeto integer NOT NULL,
    nome character varying(255) NOT NULL,
    areapesquisa character varying(255),
    tipoprojeto character varying(255) NOT NULL,
    descricao character varying(255)
);


ALTER TABLE public.projetos OWNER TO postgres;

--
-- Name: projetos_id_projeto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.projetos_id_projeto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projetos_id_projeto_seq OWNER TO postgres;

--
-- Name: projetos_id_projeto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.projetos_id_projeto_seq OWNED BY public.projetos.id_projeto;


--
-- Name: situacoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.situacoes (
    id_situacao integer NOT NULL,
    situacao character varying(255) NOT NULL
);


ALTER TABLE public.situacoes OWNER TO postgres;

--
-- Name: situacoes_id_situacao_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.situacoes_id_situacao_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.situacoes_id_situacao_seq OWNER TO postgres;

--
-- Name: situacoes_id_situacao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.situacoes_id_situacao_seq OWNED BY public.situacoes.id_situacao;


--
-- Name: skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.skills (
    id_skill integer NOT NULL,
    skill character varying(300) NOT NULL
);


ALTER TABLE public.skills OWNER TO postgres;

--
-- Name: skills_id_skill_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.skills_id_skill_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.skills_id_skill_seq OWNER TO postgres;

--
-- Name: skills_id_skill_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.skills_id_skill_seq OWNED BY public.skills.id_skill;


--
-- Name: subcategorias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subcategorias (
    categoria character varying(255) NOT NULL,
    subcategoria character varying(255) NOT NULL
);


ALTER TABLE public.subcategorias OWNER TO postgres;

--
-- Name: user_ativ; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_ativ (
    id_atividade integer NOT NULL,
    id_usuario integer NOT NULL,
    "função" character varying(255)
);


ALTER TABLE public.user_ativ OWNER TO postgres;

--
-- Name: user_proj; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_proj (
    id_usuario integer NOT NULL,
    id_projeto integer NOT NULL,
    "função" character varying(255)
);


ALTER TABLE public.user_proj OWNER TO postgres;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id_usuario integer NOT NULL,
    nome character varying(255) NOT NULL,
    sobrenome character varying(255) NOT NULL,
    matricula character varying(14) NOT NULL,
    senha character varying(255) NOT NULL,
    email character varying(500),
    cargo character varying(255) NOT NULL,
    cpf character varying(14)
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_id_usuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_id_usuario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuarios_id_usuario_seq OWNER TO postgres;

--
-- Name: usuarios_id_usuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_id_usuario_seq OWNED BY public.usuarios.id_usuario;


--
-- Name: atividades id_atividade; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atividades ALTER COLUMN id_atividade SET DEFAULT nextval('public.atividades_id_atividade_seq'::regclass);


--
-- Name: categorias id_categoria; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias ALTER COLUMN id_categoria SET DEFAULT nextval('public.categorias_id_categoria_seq'::regclass);


--
-- Name: checkins id_checkin; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkins ALTER COLUMN id_checkin SET DEFAULT nextval('public.checkins_id_checkin_seq'::regclass);


--
-- Name: condicoes id_condicao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.condicoes ALTER COLUMN id_condicao SET DEFAULT nextval('public.condicoes_id_condicao_seq'::regclass);


--
-- Name: emprestimos id_emprestimo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emprestimos ALTER COLUMN id_emprestimo SET DEFAULT nextval('public.emprestimos_id_emprestimo_seq'::regclass);


--
-- Name: instituicoes id_instituicao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instituicoes ALTER COLUMN id_instituicao SET DEFAULT nextval('public.instituicoes_id_instituicao_seq'::regclass);


--
-- Name: itenspatrimonio id_item_patrimonio; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itenspatrimonio ALTER COLUMN id_item_patrimonio SET DEFAULT nextval('public.itenspatrimonio_id_item_patrimonio_seq'::regclass);


--
-- Name: patrimonios id_patrimonio; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patrimonios ALTER COLUMN id_patrimonio SET DEFAULT nextval('public.patrimonios_id_patrimonio_seq'::regclass);


--
-- Name: projetos id_projeto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projetos ALTER COLUMN id_projeto SET DEFAULT nextval('public.projetos_id_projeto_seq'::regclass);


--
-- Name: situacoes id_situacao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.situacoes ALTER COLUMN id_situacao SET DEFAULT nextval('public.situacoes_id_situacao_seq'::regclass);


--
-- Name: skills id_skill; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skills ALTER COLUMN id_skill SET DEFAULT nextval('public.skills_id_skill_seq'::regclass);


--
-- Name: usuarios id_usuario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id_usuario SET DEFAULT nextval('public.usuarios_id_usuario_seq'::regclass);


--
-- Data for Name: ativ_proj; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ativ_proj (id_atividade, id_projeto) FROM stdin;
\.
COPY public.ativ_proj (id_atividade, id_projeto) FROM '$$PATH$$/3590.dat';

--
-- Data for Name: atividades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.atividades (id_atividade, nome, "descrição") FROM stdin;
\.
COPY public.atividades (id_atividade, nome, "descrição") FROM '$$PATH$$/3591.dat';

--
-- Data for Name: categorias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categorias (id_categoria, categoria) FROM stdin;
\.
COPY public.categorias (id_categoria, categoria) FROM '$$PATH$$/3593.dat';

--
-- Data for Name: checkins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.checkins (id_checkin, id_usuario, dat, hora) FROM stdin;
\.
COPY public.checkins (id_checkin, id_usuario, dat, hora) FROM '$$PATH$$/3595.dat';

--
-- Data for Name: condicoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.condicoes (id_condicao, condicao) FROM stdin;
\.
COPY public.condicoes (id_condicao, condicao) FROM '$$PATH$$/3597.dat';

--
-- Data for Name: emprestimos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.emprestimos (id_emprestimo, id_usuario_responsavel, id_usuario, id_item_patrimonio, dataemprestimo, datadevolucao) FROM stdin;
\.
COPY public.emprestimos (id_emprestimo, id_usuario_responsavel, id_usuario, id_item_patrimonio, dataemprestimo, datadevolucao) FROM '$$PATH$$/3599.dat';

--
-- Data for Name: instituicoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.instituicoes (id_instituicao, cnpj, "nomeinstituição", "pesresponsável") FROM stdin;
\.
COPY public.instituicoes (id_instituicao, cnpj, "nomeinstituição", "pesresponsável") FROM '$$PATH$$/3601.dat';

--
-- Data for Name: itenspatrimonio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.itenspatrimonio (id_item_patrimonio, id_patrimonio, id_situacao, id_condicao) FROM stdin;
\.
COPY public.itenspatrimonio (id_item_patrimonio, id_patrimonio, id_situacao, id_condicao) FROM '$$PATH$$/3603.dat';

--
-- Data for Name: parceiros; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parceiros (id_instituicao, id_projeto) FROM stdin;
\.
COPY public.parceiros (id_instituicao, id_projeto) FROM '$$PATH$$/3605.dat';

--
-- Data for Name: patrimonios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patrimonios (id_patrimonio, id_categoria, nome, valorestimado, descricao) FROM stdin;
\.
COPY public.patrimonios (id_patrimonio, id_categoria, nome, valorestimado, descricao) FROM '$$PATH$$/3606.dat';

--
-- Data for Name: possuiskill; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.possuiskill (id_skill, id_usuario) FROM stdin;
\.
COPY public.possuiskill (id_skill, id_usuario) FROM '$$PATH$$/3608.dat';

--
-- Data for Name: projetos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projetos (id_projeto, nome, areapesquisa, tipoprojeto, descricao) FROM stdin;
\.
COPY public.projetos (id_projeto, nome, areapesquisa, tipoprojeto, descricao) FROM '$$PATH$$/3609.dat';

--
-- Data for Name: situacoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.situacoes (id_situacao, situacao) FROM stdin;
\.
COPY public.situacoes (id_situacao, situacao) FROM '$$PATH$$/3611.dat';

--
-- Data for Name: skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.skills (id_skill, skill) FROM stdin;
\.
COPY public.skills (id_skill, skill) FROM '$$PATH$$/3613.dat';

--
-- Data for Name: subcategorias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subcategorias (categoria, subcategoria) FROM stdin;
\.
COPY public.subcategorias (categoria, subcategoria) FROM '$$PATH$$/3615.dat';

--
-- Data for Name: user_ativ; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_ativ (id_atividade, id_usuario, "função") FROM stdin;
\.
COPY public.user_ativ (id_atividade, id_usuario, "função") FROM '$$PATH$$/3616.dat';

--
-- Data for Name: user_proj; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_proj (id_usuario, id_projeto, "função") FROM stdin;
\.
COPY public.user_proj (id_usuario, id_projeto, "função") FROM '$$PATH$$/3617.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id_usuario, nome, sobrenome, matricula, senha, email, cargo, cpf) FROM stdin;
\.
COPY public.usuarios (id_usuario, nome, sobrenome, matricula, senha, email, cargo, cpf) FROM '$$PATH$$/3618.dat';

--
-- Name: atividades_id_atividade_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.atividades_id_atividade_seq', 1, false);


--
-- Name: categorias_id_categoria_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categorias_id_categoria_seq', 1, false);


--
-- Name: checkins_id_checkin_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.checkins_id_checkin_seq', 1, false);


--
-- Name: condicoes_id_condicao_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.condicoes_id_condicao_seq', 1, false);


--
-- Name: emprestimos_id_emprestimo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.emprestimos_id_emprestimo_seq', 1, false);


--
-- Name: instituicoes_id_instituicao_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.instituicoes_id_instituicao_seq', 1, false);


--
-- Name: itenspatrimonio_id_item_patrimonio_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.itenspatrimonio_id_item_patrimonio_seq', 1, false);


--
-- Name: patrimonios_id_patrimonio_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.patrimonios_id_patrimonio_seq', 1, false);


--
-- Name: projetos_id_projeto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.projetos_id_projeto_seq', 1, false);


--
-- Name: situacoes_id_situacao_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.situacoes_id_situacao_seq', 1, false);


--
-- Name: skills_id_skill_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.skills_id_skill_seq', 1, false);


--
-- Name: usuarios_id_usuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_usuario_seq', 1, false);


--
-- Name: ativ_proj ativ_proj_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ativ_proj
    ADD CONSTRAINT ativ_proj_pkey PRIMARY KEY (id_atividade, id_projeto);


--
-- Name: atividades atividades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atividades
    ADD CONSTRAINT atividades_pkey PRIMARY KEY (id_atividade);


--
-- Name: categorias categorias_categoria_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_categoria_key UNIQUE (categoria);


--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (id_categoria);


--
-- Name: checkins checkins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkins
    ADD CONSTRAINT checkins_pkey PRIMARY KEY (id_checkin, id_usuario);


--
-- Name: condicoes condicoes_condicao_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.condicoes
    ADD CONSTRAINT condicoes_condicao_key UNIQUE (condicao);


--
-- Name: condicoes condicoes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.condicoes
    ADD CONSTRAINT condicoes_pkey PRIMARY KEY (id_condicao);


--
-- Name: emprestimos emprestimos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emprestimos
    ADD CONSTRAINT emprestimos_pkey PRIMARY KEY (id_emprestimo, id_usuario_responsavel, id_usuario, id_item_patrimonio);


--
-- Name: instituicoes instituicoes_cnpj_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instituicoes
    ADD CONSTRAINT instituicoes_cnpj_key UNIQUE (cnpj);


--
-- Name: instituicoes instituicoes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instituicoes
    ADD CONSTRAINT instituicoes_pkey PRIMARY KEY (id_instituicao);


--
-- Name: itenspatrimonio itenspatrimonio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itenspatrimonio
    ADD CONSTRAINT itenspatrimonio_pkey PRIMARY KEY (id_item_patrimonio);


--
-- Name: parceiros parceiros_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parceiros
    ADD CONSTRAINT parceiros_pkey PRIMARY KEY (id_instituicao);


--
-- Name: patrimonios patrimonios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patrimonios
    ADD CONSTRAINT patrimonios_pkey PRIMARY KEY (id_patrimonio);


--
-- Name: possuiskill possuiskill_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.possuiskill
    ADD CONSTRAINT possuiskill_pkey PRIMARY KEY (id_skill, id_usuario);


--
-- Name: projetos projetos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projetos
    ADD CONSTRAINT projetos_pkey PRIMARY KEY (id_projeto);


--
-- Name: situacoes situacoes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.situacoes
    ADD CONSTRAINT situacoes_pkey PRIMARY KEY (id_situacao);


--
-- Name: situacoes situacoes_situacao_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.situacoes
    ADD CONSTRAINT situacoes_situacao_key UNIQUE (situacao);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (id_skill);


--
-- Name: skills skills_skill_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_skill_key UNIQUE (skill);


--
-- Name: subcategorias subcategorias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcategorias
    ADD CONSTRAINT subcategorias_pkey PRIMARY KEY (categoria);


--
-- Name: subcategorias subcategorias_subcategoria_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcategorias
    ADD CONSTRAINT subcategorias_subcategoria_key UNIQUE (subcategoria);


--
-- Name: user_ativ user_ativ_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_ativ
    ADD CONSTRAINT user_ativ_pkey PRIMARY KEY (id_atividade, id_usuario);


--
-- Name: user_proj user_proj_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_proj
    ADD CONSTRAINT user_proj_pkey PRIMARY KEY (id_usuario, id_projeto);


--
-- Name: usuarios usuarios_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_cpf_key UNIQUE (cpf);


--
-- Name: usuarios usuarios_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_email_key UNIQUE (email);


--
-- Name: usuarios usuarios_matricula_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_matricula_key UNIQUE (matricula);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id_usuario);


--
-- Name: ativ_proj ativ_proj_id_atividade_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ativ_proj
    ADD CONSTRAINT ativ_proj_id_atividade_fkey FOREIGN KEY (id_atividade) REFERENCES public.atividades(id_atividade);


--
-- Name: ativ_proj ativ_proj_id_projeto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ativ_proj
    ADD CONSTRAINT ativ_proj_id_projeto_fkey FOREIGN KEY (id_projeto) REFERENCES public.projetos(id_projeto);


--
-- Name: checkins checkins_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkins
    ADD CONSTRAINT checkins_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id_usuario);


--
-- Name: emprestimos emprestimos_id_item_patrimonio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emprestimos
    ADD CONSTRAINT emprestimos_id_item_patrimonio_fkey FOREIGN KEY (id_item_patrimonio) REFERENCES public.itenspatrimonio(id_item_patrimonio);


--
-- Name: emprestimos emprestimos_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emprestimos
    ADD CONSTRAINT emprestimos_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id_usuario);


--
-- Name: emprestimos emprestimos_id_usuario_responsavel_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emprestimos
    ADD CONSTRAINT emprestimos_id_usuario_responsavel_fkey FOREIGN KEY (id_usuario_responsavel) REFERENCES public.usuarios(id_usuario);


--
-- Name: itenspatrimonio itenspatrimonio_id_condicao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itenspatrimonio
    ADD CONSTRAINT itenspatrimonio_id_condicao_fkey FOREIGN KEY (id_condicao) REFERENCES public.condicoes(id_condicao);


--
-- Name: itenspatrimonio itenspatrimonio_id_patrimonio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itenspatrimonio
    ADD CONSTRAINT itenspatrimonio_id_patrimonio_fkey FOREIGN KEY (id_patrimonio) REFERENCES public.patrimonios(id_patrimonio);


--
-- Name: itenspatrimonio itenspatrimonio_id_situacao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itenspatrimonio
    ADD CONSTRAINT itenspatrimonio_id_situacao_fkey FOREIGN KEY (id_situacao) REFERENCES public.situacoes(id_situacao);


--
-- Name: parceiros parceiros_id_instituicao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parceiros
    ADD CONSTRAINT parceiros_id_instituicao_fkey FOREIGN KEY (id_instituicao) REFERENCES public.instituicoes(id_instituicao);


--
-- Name: parceiros parceiros_id_projeto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parceiros
    ADD CONSTRAINT parceiros_id_projeto_fkey FOREIGN KEY (id_projeto) REFERENCES public.projetos(id_projeto);


--
-- Name: patrimonios patrimonios_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patrimonios
    ADD CONSTRAINT patrimonios_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.categorias(id_categoria);


--
-- Name: possuiskill possuiskill_id_skill_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.possuiskill
    ADD CONSTRAINT possuiskill_id_skill_fkey FOREIGN KEY (id_skill) REFERENCES public.skills(id_skill);


--
-- Name: possuiskill possuiskill_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.possuiskill
    ADD CONSTRAINT possuiskill_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id_usuario);


--
-- Name: subcategorias subcategorias_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcategorias
    ADD CONSTRAINT subcategorias_categoria_fkey FOREIGN KEY (categoria) REFERENCES public.categorias(categoria);


--
-- Name: user_ativ user_ativ_id_atividade_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_ativ
    ADD CONSTRAINT user_ativ_id_atividade_fkey FOREIGN KEY (id_atividade) REFERENCES public.atividades(id_atividade);


--
-- Name: user_ativ user_ativ_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_ativ
    ADD CONSTRAINT user_ativ_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id_usuario);


--
-- Name: user_proj user_proj_id_projeto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_proj
    ADD CONSTRAINT user_proj_id_projeto_fkey FOREIGN KEY (id_projeto) REFERENCES public.projetos(id_projeto);


--
-- Name: user_proj user_proj_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_proj
    ADD CONSTRAINT user_proj_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id_usuario);


--
-- PostgreSQL database dump complete
--

